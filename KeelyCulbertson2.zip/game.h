//Constants
#define WORLDWIDTH 1024
#define WORLDHEIGHT 256

//Variables
extern int tasks;
extern int cheat;
extern int voff;
extern int hoff;
extern int sb;
extern int anicounter;
extern int gooseHoff;
extern int overallHoff;


//Methods
void initGame();
void updateGame();
void drawGame();