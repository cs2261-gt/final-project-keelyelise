
//{{BLOCK(gardenCollision)

//======================================================================
//
//	gardenCollision, 1024x1024@16, 
//	+ bitmap not compressed
//	Total size: 2097152 = 2097152
//
//	Time-stamp: 2020-04-02, 21:41:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GARDENCOLLISION_H
#define GRIT_GARDENCOLLISION_H

#define gardenCollisionBitmapLen 2097152
extern const unsigned short gardenCollisionBitmap[1048576];

#endif // GRIT_GARDENCOLLISION_H

//}}BLOCK(gardenCollision)
