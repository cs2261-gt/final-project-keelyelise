
//{{BLOCK(tempCollision)

//======================================================================
//
//	tempCollision, 1024x256@16, 
//	+ bitmap not compressed
//	Total size: 524288 = 524288
//
//	Time-stamp: 2020-04-08, 15:52:11
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TEMPCOLLISION_H
#define GRIT_TEMPCOLLISION_H

#define tempCollisionBitmapLen 524288
extern const unsigned short tempCollisionBitmap[262144];

#endif // GRIT_TEMPCOLLISION_H

//}}BLOCK(tempCollision)
