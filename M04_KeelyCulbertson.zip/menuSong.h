#ifndef __MENUSONGH__
#define __MENUSONGH__

#define MENUSONGLEN 1805505
extern const signed char menuSong[1805505];

#endif