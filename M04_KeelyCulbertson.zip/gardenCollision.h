
//{{BLOCK(gardenCollision)

//======================================================================
//
//	gardenCollision, 1024x256@16, 
//	+ bitmap not compressed
//	Total size: 524288 = 524288
//
//	Time-stamp: 2020-04-22, 19:13:46
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GARDENCOLLISION_H
#define GRIT_GARDENCOLLISION_H

#define gardenCollisionBitmapLen 524288
extern const unsigned short gardenCollisionBitmap[262144];

#endif // GRIT_GARDENCOLLISION_H

//}}BLOCK(gardenCollision)
