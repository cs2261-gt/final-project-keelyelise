#ifndef __WRITINGH__
#define __WRITINGH__

#define WRITINGLEN 28400
extern const signed char writing[28400];

#endif