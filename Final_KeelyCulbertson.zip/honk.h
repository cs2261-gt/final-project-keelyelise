#ifndef __HONKH__
#define __HONKH__

#define HONKLEN 5742
extern const signed char honk[5742];

#endif