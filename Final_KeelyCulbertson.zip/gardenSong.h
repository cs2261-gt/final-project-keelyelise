#ifndef __GARDENSONGH__
#define __GARDENSONGH__

#define GARDENSONGLEN 1373015
extern const signed char gardenSong[1373015];

#endif